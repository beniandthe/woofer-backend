from .base import *  # noqa

DEBUG = False
